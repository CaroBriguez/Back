<?php
session_start();
if (isset($_SESSION['usuario'])) {
  $usuario = $_SESSION['usuario'];
}
else {
  header ("location:login.html" );
}

 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title></title>
   </head>
   <body>

<h1>Bienvenido super usuario <?php echo $_SESSION['usuario'] ?> </h1>

<br>
<a href="cerrarsesion.php"> cerrar sesion</a>

<h2>imaginen que aca esta el ABM</h2>


   </body>
 </html>
